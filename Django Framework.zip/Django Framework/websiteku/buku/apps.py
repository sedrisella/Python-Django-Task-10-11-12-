from django.apps import AppConfig


class BukuConfig(AppConfig):
    name = 'buku'
